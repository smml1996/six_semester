//
// Created by Stefanie Muroya lei on 11/4/18.
//
#include <iostream>

using namespace std;
namespace Util {
    struct Rectangle{
        double minX, minY;
        double maxX, maxY;
    };

    struct Point{
        double x,y;
    };

};
